<!DOCTYPE html>
<html lang="pt-br">  
<head>
  <meta charset="utf-8">
  <title>MemePédia</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/style-normas-de-conduta.css">
</head>
<body>
    <h1 class="ttlNormasDeConduta">Navegação</h1>
    <p class="txt">
    A Memepédia contém uma vasta quantidade de informação sobre os mais variados 
    assuntos, para não dizer todos. Para explorar um tema, vá até à página principal, 
    encontre o que lhe interessa e comece a exploração. Existe também um campo de 
    busca (no topo à direita) que pode ser utilizado para encontrar informação rapidamente.
    Caso não encontre algum assunto ou tenha dificuldade de encontrá-lo, 
    registre sua necessidade na lista de solicitação de artigos. 
    Por outro lado, se num artigo não encontrar toda a informação relevante, 
    pode usar a página de discussão desse artigo para colocar as suas dúvidas e sugestões.
    </p>
</body>