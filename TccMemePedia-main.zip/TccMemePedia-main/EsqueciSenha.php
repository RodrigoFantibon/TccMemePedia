<!DOCTYPE html>  


<html lang="pt-br">
<meta charset="utf-8">
<html>
<head>
<title> Recuperar Senha </title>
</head>
<body>

<form name="form1" method="post" action="RecuperaSenha.php">
<font face=Tahoma size=2 color=black><br>
<div align="center"><b></b> 
 <input class=""name="email" type="text1" id="email" placeholder="Digite seu email de cadastro !" size="40" autofocus required />
<input name="recupera" type="hidden" id="recupera" value="recupera" />
<input type="submit" name="Submit" value="Verificar">
</p>
</form>

</style>
</form>

</body>
</html>
